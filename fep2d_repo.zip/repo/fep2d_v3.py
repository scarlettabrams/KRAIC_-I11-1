"""
fep2d_v3.py
=============================================================
V3 = the V2 maths UNCHANGED, plus what the two-tab app needs: find_frames,
progress callbacks, a robust batch loop (one bad file never stops a run,
resume with skip_existing, multi-frame files, errors.csv, run manifest).
fep2d_v2.py is left untouched and is still the reference implementation.

2D (pre-integration) background subtraction for I11 Pixium flow PXRD.
Rebuilt from scratch around the AP39 1D findings.

Design principles (from AP39)
-----------------------------
1. The reference is a MERGED frame: many background-only frames averaged
   to maximise SNR (AP39: 93 to 112 frames per reference; 5 frames was
   visibly too few).
2. Frame selection is NOT done here. Visual triage in the Streamlit app
   already labels diffraction / background / reference. This module only
   screens out physically bad frames (shutter closed, detector out of
   position) before they enter a reference.
3. Subtraction, not division (AP39: higher relative peak intensity, same
   peak positions).
4. The scale factor is fitted PER FRAME against the reference, because
   intensity drifts over a run. Bragg spots are rejected from the fit so
   they do not bias the scale.
5. Negative pixels are kept by default (clipping biases low-signal
   regions upward). pyFAI integrates negatives fine.

Typical use
-----------
    ref_paths = find_frames("E:/run/reference_frames/")
    ref = build_reference(ref_paths, mask=mask, label="70:30 EtOH:H2O")
    save_reference(ref, "ref_70_30.npz")

    table = process_run(sample_paths, ref, "Corrected_2D/", mask=mask,
                        ai=ai, xy_dir="Integrated_2Dcorr/")

Requires: numpy, h5py. Optional: pyFAI (only for xy output).
"""
from __future__ import annotations

import csv
import datetime
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Sequence, Union

import h5py
import numpy as np

PathLike = Union[str, Path]

DETECTOR_PATHS = (
    "entry1/pixium_hdf/data",
    "entry/data/data",
    "entry1/data/data",
    "entry1/Pixium10:detector/data",
    "entry/Pixium10:detector/data",
    "entry1/detector/data",
    "entry/detector/data",
)


# ----------------------------------------------------------------------------
# I/O
# ----------------------------------------------------------------------------
def _detector_path(f: h5py.File) -> str:
    for p in DETECTOR_PATHS:
        if p in f:
            return p
    found = []
    f.visititems(lambda n, o: found.append(n)
                 if isinstance(o, h5py.Dataset) and o.ndim >= 2 else None)
    if not found:
        raise RuntimeError("No 2D/3D dataset found")
    return max(found, key=lambda n: int(np.prod(f[n].shape[-2:])))


def iter_frames(paths: Sequence[PathLike]):
    """Yield (path, frame_index, 2D float32 array); handles 2D or 3D datasets."""
    for p in paths:
        with h5py.File(p, "r") as f:
            ds = f[_detector_path(f)]
            if ds.ndim == 2:
                yield str(p), 0, ds[()].astype(np.float32)
            else:
                for i in range(ds.shape[0]):
                    yield str(p), i, ds[i].astype(np.float32)


def find_frames(folder: PathLike, exts=(".nxs",), recursive: bool = False) -> list:
    """Sorted list of frame files in a folder. Default is .nxs only, because each
    .nxs links to its own pixium_<n>.hdf and listing both would double count."""
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Folder not found: {folder}")
    exts = tuple(e.lower() for e in exts)
    it = folder.rglob("*") if recursive else folder.glob("*")
    return sorted(str(p) for p in it if p.is_file() and p.suffix.lower() in exts)


def n_frames_in_file(path: PathLike) -> int:
    with h5py.File(path, "r") as f:
        ds = f[_detector_path(f)]
        return 1 if ds.ndim == 2 else int(ds.shape[0])


def _valid(mask: Optional[np.ndarray], shape) -> np.ndarray:
    """Boolean array, True = usable pixel. pyFAI convention: mask True = bad."""
    if mask is None:
        return np.ones(shape, bool)
    if mask.shape != shape:
        raise ValueError(f"mask {mask.shape} vs frame {shape}")
    return ~mask.astype(bool)


def _thumb(a: np.ndarray, b: int = 16) -> np.ndarray:
    """Block-mean downsample for cheap frame comparison."""
    r, c = (a.shape[0] // b) * b, (a.shape[1] // b) * b
    return a[:r, :c].reshape(r // b, b, c // b, b).mean(axis=(1, 3))


# ----------------------------------------------------------------------------
# Reference building
# ----------------------------------------------------------------------------
@dataclass
class Reference:
    mean: np.ndarray                 # merged background, float32
    var_of_mean: np.ndarray          # per-pixel variance of the merged mean
    label: str
    n_used: int
    n_rejected: int
    sources: list = field(default_factory=list)
    rejected: list = field(default_factory=list)   # (file, idx, reason)


def screen_frames(paths, mask=None, min_total_frac=0.3, z_total=5.0, min_corr=0.97,
                  progress=None):
    """
    Pass 1: cheap screen. Returns (keep_list, reject_list).
    Reject if total counts are far below the median (shutter closed), are a
    robust outlier, or the thumbnail correlates poorly with the median
    thumbnail (detector out of position / different scene).
    """
    recs = []
    for p, i, fr in iter_frames(paths):
        v = _valid(mask, fr.shape)
        recs.append((p, i, float(fr[v].sum()), _thumb(np.where(v, fr, 0.0))))
        if progress:
            progress("screening", len(recs), len(paths))
    if not recs:
        raise RuntimeError("No frames found")

    totals = np.array([r[2] for r in recs])
    med = np.median(totals)
    mad = 1.4826 * np.median(np.abs(totals - med)) + 1e-12
    med_thumb = np.median(np.stack([r[3] for r in recs]), axis=0).ravel()
    med_thumb = (med_thumb - med_thumb.mean()) / (med_thumb.std() + 1e-12)

    keep, rej = [], []
    for (p, i, tot, th) in recs:
        t = th.ravel()
        corr = float(np.mean(((t - t.mean()) / (t.std() + 1e-12)) * med_thumb))
        if tot < min_total_frac * med:
            rej.append((p, i, "low_total (shutter closed?)"))
        elif abs(tot - med) > z_total * mad:
            rej.append((p, i, "total_outlier"))
        elif corr < min_corr:
            rej.append((p, i, f"scene_mismatch corr={corr:.3f}"))
        else:
            keep.append((p, i))
    return keep, rej


def build_reference(paths: Sequence[PathLike], mask=None, label="reference",
                    screen=True, progress=None, **screen_kw) -> Reference:
    """Streaming mean + variance (Welford) so 100 frames never sit in RAM.
    progress(stage, done, total) is called after every frame if given."""
    if screen:
        keep, rej = screen_frames(paths, mask, progress=progress, **screen_kw)
    else:
        keep, rej = [(p, i) for p, i, _ in iter_frames(paths)], []
    keep_set = set(keep)
    if not keep_set:
        raise RuntimeError("All frames rejected by screening")

    n, mean, m2 = 0, None, None
    for p, i, fr in iter_frames(paths):
        if (p, i) not in keep_set:
            continue
        fr = fr.astype(np.float64)
        if mean is None:
            mean, m2 = np.zeros_like(fr), np.zeros_like(fr)
        n += 1
        d = fr - mean
        mean += d / n
        m2 += d * (fr - mean)
        if progress:
            progress("merging", n, len(keep_set))
    var = (m2 / max(n - 1, 1)) / n          # variance of the mean
    return Reference(mean.astype(np.float32), var.astype(np.float32), label,
                     n, len(rej), sorted(keep_set), rej)


def save_reference(ref: Reference, path: PathLike) -> None:
    np.savez_compressed(path, mean=ref.mean, var_of_mean=ref.var_of_mean,
                        label=ref.label, n_used=ref.n_used,
                        n_rejected=ref.n_rejected,
                        sources=np.array([f"{p}::{i}" for p, i in ref.sources]))


def load_reference(path: PathLike) -> Reference:
    z = np.load(path, allow_pickle=False)
    srcs = [tuple(s.rsplit("::", 1)) for s in z["sources"]]
    return Reference(z["mean"], z["var_of_mean"], str(z["label"]),
                     int(z["n_used"]), int(z["n_rejected"]),
                     [(a, int(b)) for a, b in srcs])


# ----------------------------------------------------------------------------
# Scale + subtraction
# ----------------------------------------------------------------------------
def fit_scale(frame, ref_mean, mask=None, n_iter=6, clip=3.0,
              r_range: Optional[tuple] = None, fit_offset=False,
              centre: Optional[tuple] = None,
              fit_region: Optional[np.ndarray] = None):
    """
    Robust least-squares scale s (and optional offset) so frame ~ s*ref + c.
    Iteratively rejects pixels with large POSITIVE residuals (Bragg spots)
    and extreme negative ones, so crystal signal does not inflate s.
    r_range=(rmin, rmax) in pixels restricts the fit to an annulus
    (e.g. an FEP-dominated region); None = all valid pixels.
    centre=(row, col) is the beam centre in pixels (get it from the .poni
    via beam_centre_px(ai)); defaults to the frame centre.
    fit_region = boolean array (True = use) built with tth_region(); this is the
    2D equivalent of the 'Scaling region' (2theta range) in the 1D app.
    """
    v = _valid(mask, frame.shape)
    if fit_region is not None:
        v &= fit_region.astype(bool)
    if r_range is not None:
        cy, cx = centre if centre is not None else \
            (frame.shape[0] / 2.0, frame.shape[1] / 2.0)
        y, x = np.ogrid[:frame.shape[0], :frame.shape[1]]
        r = np.hypot(x - cx, y - cy)
        v &= (r >= r_range[0]) & (r <= r_range[1])
    f = frame[v].astype(np.float64)
    g = ref_mean[v].astype(np.float64)
    use = np.ones(f.size, bool)
    s, c = 1.0, 0.0
    for _ in range(n_iter):
        if fit_offset:
            A = np.column_stack([g[use], np.ones(use.sum())])
            (s, c), *_ = np.linalg.lstsq(A, f[use], rcond=None)
        else:
            s = float((f[use] * g[use]).sum() / ((g[use] ** 2).sum() + 1e-12))
        res = f - (s * g + c)
        sig = 1.4826 * np.median(np.abs(res[use] - np.median(res[use]))) + 1e-12
        use = (res < clip * sig) & (res > -clip * 2 * sig)
    return float(s), float(c), float(use.mean())


def beam_centre_px(ai) -> tuple:
    """(row, col) beam centre in pixels from a pyFAI AzimuthalIntegrator."""
    f2d = ai.getFit2D()
    return float(f2d["centerY"]), float(f2d["centerX"])


def subtract_frame(frame, ref: Reference, mask=None, scale: Optional[float] = None,
                   clip_negative=False, **fit_kw):
    s, c, frac_used = (scale, 0.0, 1.0) if scale is not None else \
        fit_scale(frame, ref.mean, mask, **fit_kw)
    out = frame - (s * ref.mean + c)
    if mask is not None:
        out = np.where(mask.astype(bool), 0.0, out)
    v = _valid(mask, frame.shape)
    neg_frac = float((out[v] < 0).mean())
    if clip_negative:
        out = np.clip(out, 0.0, None)
    info = dict(scale=s, offset=c, fit_pixel_frac=frac_used,
                neg_frac=neg_frac, corrected_sum=float(out[v].sum()))
    return out.astype(np.float32), info


# ----------------------------------------------------------------------------
# Helpers added after first real-data trial
# ----------------------------------------------------------------------------
def tth_annulus_mask(ai, shape, ranges_deg) -> np.ndarray:
    """
    Boolean mask (True = bad, pyFAI convention) covering one or more 2theta
    ranges in degrees, e.g. [(5.45, 6.0)] for the strong FEP reflection.
    OR it with your detector mask:  mask2 = mask.astype(bool) | tth_annulus_mask(...)
    Masked pixels are excluded from the scale fit, zeroed in the corrected
    frame and ignored on integration.
    """
    try:                                    # newer pyFAI
        tth = np.degrees(ai.center_array(shape, unit="2th_rad"))
    except (AttributeError, TypeError, ValueError):   # older pyFAI
        tth = np.degrees(ai.twoThetaArray(shape))
    m = np.zeros(shape, bool)
    for lo, hi in ranges_deg:
        m |= (tth >= lo) & (tth <= hi)
    return m


def tth_region(ai, shape, rng_deg) -> np.ndarray:
    """Boolean array, True INSIDE a single 2theta range (lo, hi) in degrees.
    Use as fit_region= to restrict the scale fit, like the app's Scaling region."""
    return tth_annulus_mask(ai, shape, [tuple(rng_deg)])


def interpolate_gap(x, y, lo, hi):
    """Straight-line fill across [lo, hi] using the edge values. Same logic as
    mask_region(method='interpolate') in app_ssa_V4, so masked 2theta ranges
    give a continuous pattern before baselining."""
    y_out = np.array(y, dtype=float).copy()
    region = (x >= lo) & (x <= hi)
    if not region.any():
        return y_out
    idx = np.where(region)[0]
    a, b = idx[0], idx[-1]
    lo_val = y_out[a - 1] if a > 0 else y_out[b + 1] if b + 1 < len(y_out) else 0.0
    hi_val = y_out[b + 1] if b + 1 < len(y_out) else lo_val
    y_out[region] = np.linspace(lo_val, hi_val, region.sum())
    return y_out


@dataclass
class RingMap:
    order: np.ndarray        # flat indices of valid pixels, sorted by radial (2theta) bin
    bounds: np.ndarray       # start offset of each bin inside `order` (len nbins+1)
    shape: tuple


def build_ring_map(ai, shape, mask=None, nbins=1500) -> RingMap:
    """Precompute once per geometry/mask; reuse for every frame."""
    try:
        tth = np.degrees(ai.center_array(shape, unit="2th_rad"))
    except (AttributeError, TypeError, ValueError):
        tth = np.degrees(ai.twoThetaArray(shape))
    valid = _valid(mask, shape)
    flat_valid = np.flatnonzero(valid.ravel())
    t = tth.ravel()[flat_valid]
    edges = np.linspace(t.min(), t.max(), nbins + 1)
    lab = np.clip(np.digitize(t, edges) - 1, 0, nbins - 1)
    srt = np.argsort(lab, kind="stable")
    counts = np.bincount(lab, minlength=nbins)
    return RingMap(flat_valid[srt], np.concatenate([[0], np.cumsum(counts)]), tuple(shape))


def ring_median_subtract(frame, rm: RingMap) -> np.ndarray:
    """
    Subtract the median of each radial ring (a robust 'azimuthal background').
    Anything smooth around a ring (FEP, solvent halo, leftover reference
    mismatch) is removed; localised features (Bragg spots) stay. Masked pixels = 0.
    """
    vals = frame.ravel()[rm.order].astype(np.float32)
    med = np.empty_like(vals)
    b = rm.bounds
    for k in range(len(b) - 1):
        s_, e_ = b[k], b[k + 1]
        med[s_:e_] = np.median(vals[s_:e_]) if e_ > s_ else 0.0
    out = np.zeros(frame.size, dtype=np.float32)
    out[rm.order] = vals - med
    return out.reshape(rm.shape)


def leave_one_out_reference(ref: Reference, frame: np.ndarray) -> Reference:
    """
    Reference with ONE of its own frames removed (exact, no re-reading).
    `frame` must be one of the frames that went into `ref` (see ref.sources).
    Subtracting it from that frame is a pure noise test: any structure left
    means a problem in the code or scale fit, not in reference matching.
    """
    n = ref.n_used
    if n < 3:
        raise ValueError("Need at least 3 frames in the reference")
    mean = (n * ref.mean.astype(np.float64) - frame.astype(np.float64)) / (n - 1)
    return Reference(mean.astype(np.float32),
                     (ref.var_of_mean * (n / (n - 1))).astype(np.float32),
                     ref.label + " (leave-one-out)", n - 1, ref.n_rejected,
                     list(ref.sources), list(ref.rejected))


# ----------------------------------------------------------------------------
# Output
# ----------------------------------------------------------------------------
def write_corrected_nxs(src: PathLike, dst: PathLike, corrected, frame_index,
                        ref: Reference, info: dict) -> None:
    """
    Copy the source file, swap in the corrected 2D frame (single frame).
    I11 .nxs files hold an EXTERNAL LINK to the matching pixium_<n>.hdf. The
    link is relative, so it breaks when the .nxs is copied to another folder.
    So: attributes are read from the SOURCE (where the link resolves), and in
    the copy the link is simply unlinked and replaced by the corrected data,
    which makes the output file self-contained (no .hdf needed beside it).
    """
    with h5py.File(src, "r") as fs:
        p = _detector_path(fs)
        attrs = dict(fs[p].attrs)
    shutil.copy2(src, dst)
    with h5py.File(dst, "r+") as f:
        try:
            del f[p]                  # unlink only; never opens the (now dangling) target
        except KeyError:
            pass
        ds = f.create_dataset(p, data=corrected[None, ...] if corrected.ndim == 2
                              else corrected, compression="gzip", compression_opts=1,
                              shuffle=True)
        for k, v in attrs.items():
            ds.attrs[k] = v
        ds.attrs.update(
            processing="fep2d_v2 pixel-wise reference subtraction",
            reference_label=ref.label, reference_n_frames=ref.n_used,
            scale_factor=info["scale"], offset=info["offset"],
            source_frame_index=frame_index,
            timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        )


def integrate_to_xy(corrected, ai, mask, out_path, npt=2000, rmin=1.0, rmax=30.0,
                    interp_ranges=None):
    """Same settings as the Streamlit app (no solid-angle correction).
    interp_ranges=[(lo, hi), ...] fills those 2theta ranges by straight line
    (use the same ranges as any annulus mask, e.g. [(5.40, 6.00)])."""
    import pyFAI
    res = ai.integrate1d(corrected.astype(np.float32), npt,
                         unit=pyFAI.units.TTH_DEG, radial_range=[rmin, rmax],
                         mask=mask, correctSolidAngle=False, error_model=None)
    x, y = np.asarray(res.radial), np.asarray(res.intensity)
    for lo, hi in (interp_ranges or []):
        y = interpolate_gap(x, y, lo, hi)
    np.savetxt(out_path, np.column_stack([x, y]),
               header="2theta(deg) Intensity_2Dcorr", comments="", fmt="%.6f")


def process_run(sample_paths: Sequence[PathLike], ref: Reference,
                out_dir: PathLike, mask=None, ai=None,
                xy_dir: Optional[PathLike] = None, write_nxs=True,
                npt=2000, rmin=1.0, rmax=30.0, suffix="_2Dcorr",
                interp_ranges=None, progress=None, skip_existing=False,
                stop_flag=None, **kw) -> list:
    """
    Subtract the reference from every frame in sample_paths.

    Same maths as V2. Differences:
    - progress(done, total, name) is called after every file.
    - A file that fails is recorded in subtraction_errors.csv and the run goes on.
    - skip_existing=True skips files whose corrected output already exists and
      keeps their old rows in subtraction_diagnostics.csv, so a stopped run resumes.
    - stop_flag() returning True stops cleanly after the current file.
    - A file with more than one frame is written as <stem>_f0000<suffix> etc.
    Output files keep the source extension. suffix="" keeps original names, so
    write into a separate out_dir and existing sorting scripts can read it.
    **kw goes to subtract_frame / fit_scale (e.g. fit_region=, fit_offset=).
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if xy_dir:
        Path(xy_dir).mkdir(parents=True, exist_ok=True)

    csv_path = out_dir / "subtraction_diagnostics.csv"
    old_rows = {}
    if skip_existing and csv_path.exists():
        with open(csv_path, newline="") as fh:
            for r in csv.DictReader(fh):
                old_rows[(r["file"], int(r["frame"]))] = r

    rows, errors, total = [], [], len(sample_paths)
    for order, p in enumerate(sample_paths):
        if stop_flag is not None and stop_flag():
            break
        p = Path(p)
        try:
            nfr = n_frames_in_file(p)
            for _, i, fr in iter_frames([p]):
                stem = p.stem + (f"_f{i:04d}" if nfr > 1 else "")
                dst = out_dir / f"{stem}{suffix}{p.suffix}"
                if skip_existing and dst.exists() and (p.name, i) in old_rows:
                    rows.append(old_rows[(p.name, i)])
                    continue
                corr, info = subtract_frame(fr, ref, mask, **kw)
                if write_nxs:
                    write_corrected_nxs(p, dst, corr, i, ref, info)
                if xy_dir and ai is not None:
                    integrate_to_xy(corr, ai, mask, Path(xy_dir) / f"{stem}{suffix}.xy",
                                    npt, rmin, rmax, interp_ranges)
                rows.append(dict(order=order, file=p.name, frame=i, **info))
        except Exception as e:                      # one bad file must not stop a run
            errors.append(dict(file=p.name, error=f"{type(e).__name__}: {e}"))
        if progress:
            progress(order + 1, total, p.name)

    if rows:
        with open(csv_path, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
    if errors:
        with open(out_dir / "subtraction_errors.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=["file", "error"])
            w.writeheader()
            w.writerows(errors)
    process_run.last_errors = errors
    return rows
